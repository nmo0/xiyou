<?php

$config['host'] = '127.0.0.1';