<?php




  //cmd及超链接值
$cmid=$cmid+1;
$cdid[]=$cmid;
$clj[]=351;
$npc[]=$csid;//需要改动
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>【副本如意传送门】（vip玩家专用）</font></a>"."<br>";
 
  

?>







