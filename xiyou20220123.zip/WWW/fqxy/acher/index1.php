<?php
echo "<META HTTP-EQUIV=REFRESH CONTENT='0;URL=../index.php'>";
?>




