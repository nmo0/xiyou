<?php
header("Content-type: text/html; charset=utf-8");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- TemplateBeginEditable name="doctitle" -->
<title>幻想西游提示</title>
<!-- TemplateEndEditable -->
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
<link rel="shortcut icon" href="../pic/ico/favicon.ico"/>
</head>

<body>

<div style='width: device-width;display:block;word-break: break-all;word-wrap: break-word;'>

<?php


echo "<font color=red>纳尼？？你是火星来的的吧？不要妄想找到源代码！！社会社会...</font>"."<br>";
echo "<br>";

echo "<a href='../login.php'><font color=blue>返回登录</font></a>"."<br>";
echo "<font color=black>----------------------</font>"."<br>";
echo "<br>";
echo "<a href='../index.php'><font color=blue>返回社区</font></a>"."<br>";



?>


</div>


</body>
</html>




