<?php



$manzu1="";
$kcrl="";
$wpdz1="";//初始
$wpdz2="";//初始
$wpdz3="";//初始
$wpdz4="";//初始
$wpdz5="";//初始


$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖探险符〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=579;//物品id
$wpdz4[]=3;//	量
$wpdz5[]=1;//	重量
//物品加



//随机
$bz= rand(1, 110);

if($bz >=1&&$bz <=10){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖金魂〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=311;//物品id
$wpdz4[]=50;//	量
$wpdz5[]=1;//	重量
//物品加
} elseif($bz >=11&&$bz <=20){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖钻魂〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=312;//物品id
$wpdz4[]=50;//	量
$wpdz5[]=1;//	重量
//物品加

} elseif($bz >=21&&$bz <=30){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖陨魂〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=313;//物品id
$wpdz4[]=50;//	量
$wpdz5[]=1;//	重量
//物品加

} elseif($bz >=31&&$bz <=35){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖银星升星符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=316;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加


} elseif($bz >=36&&$bz <=40){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖铜星升星符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=315;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加

} elseif($bz >=41&&$bz <=45){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖金星升星符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=317;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加



} elseif($bz >=46&&$bz <=50){ 
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖钻星升星符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=318;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加




} elseif($bz >=51&&$bz <=55){ 
//随机
$sl= rand(1, 10);	
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖冠军宝石包〗（1个）";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=566;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加


} elseif($bz >=56&&$bz <=60){ 
$uuu=$uuu+1;
	//随机
$sl= rand(1, 10);	
//物品加
$wpdz1[]="〖大号财宝箱〗";//名字
$wpdz2[]=8;//物品分类
$wpdz3[]=487;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加

} elseif($bz >=61&&$bz <=70){ 



$bz= rand(1, 100);
if($bz <=10){ 
$bz= rand(1, 10);
$uuu=$uuu+1;
//随机
$bz= rand(1, 10);
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖时装碎片〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=818;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加


} else {


} 





} elseif($bz >=71&&$bz <=110){ 
//随机

$bz= rand(1, 100);
if($bz <=10){ 
$bz= rand(1, 10);
$uuu=$uuu+1;
//物品加
$wpdz1[]="〖时装契约〗";//名字
$wpdz2[]=2;//物品分类
$wpdz3[]=819;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加

} else {


} 





} else {

}




//随机
$bz= rand(1, 5);

if($bz ==1){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="【占星秘典】";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=730;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}







//随机
$bz= rand(1, 10);

if($bz ==1){
$sl= rand(1, 50);	
	
$uuu=$uuu+1;	
//物品加
$wpdz1[]="【小宇宙】";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=729;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}








//随机
$bz= rand(1, 300);

if($bz ==1){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖诛仙令〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=593;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}

//随机
$bz= rand(1, 500);

if($bz <=20){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖双倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=454;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}


//随机
$bz= rand(1, 1000);

if($bz <=10){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖四倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=455;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}

//随机
$bz= rand(1, 1800);

if($bz <=5){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖八倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=456;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}












//随机
$bz= rand(1, 500);

if($bz <=5){
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖陨星升星符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=319;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}



//随机
$bz= rand(1, 500);

if($bz <=5){
//随机
$sl= rand(1, 10);	
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖王者宝石包〗（1个）";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=587;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}

//随机
$bz= rand(1, 500);

if($bz <=5){
//随机
$sl= rand(1, 10);		
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖冠军宝石包〗（1个）";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=566;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}





//随机
$bz= rand(1, 50);

if($bz <=5){
	//随机
$sl= rand(1, 10);		
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖1亿修炼经验丹〗";//名字
$wpdz2[]=5;//物品分类
$wpdz3[]=625;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}


//随机
$bz= rand(1, 150);

if($bz <=5){
	//随机
$sl= rand(1, 10);		
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖5亿修炼经验丹〗";//名字
$wpdz2[]=5;//物品分类
$wpdz3[]=626;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}


//随机
$bz= rand(1, 300);

if($bz <=5){
	//随机
$sl= rand(1, 10);		
$uuu=$uuu+1;	
//物品加
$wpdz1[]="〖10亿修炼经验丹〗";//名字
$wpdz2[]=5;//物品分类
$wpdz3[]=627;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加
} else {

}





















$iii= date('i')*1;
$sss= date('s')*1;
$h= date('H')*1;

if($h ==11||$h ==17||$h ==21){
	
if($iii >=1&&$iii <=10){
	
echo "<font color=black>【幸运女神与财神时间，他们会擦出怎么样的火花呢】</font>"."<br>";
} else {
}



if($iii==1&&$sss==10||$iii==1&&$sss==20||$iii==1&&$sss==30||$iii==1&&$sss==40||$iii==1&&$sss==50){
//随机
$bz= rand(1, 2);
if($bz ==1){
echo "<font color=red>你受到了幸运女神的垂爱（运气爆棚~~财神驾到）</font>"."<br>";



$bz= rand(1, 50);
//物品加
$wpdz1[]="【金秋的思念】";//名字
$wpdz2[]=6;//物品分类
$wpdz3[]=744;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加





//物品加
$wpdz1[]="〖金豆〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=127;//物品id
$wpdz4[]=22;//	量
$wpdz5[]=1;//	重量
//物品加
	//随机
$sl= rand(1, 10);
//物品加
$wpdz1[]="〖冠军宝石包〗（1个）";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=566;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量
//物品加

include("./ini/zt_ini.php");
$wjmz=($iniFile->getItem('玩家信息','玩家名字'));
$xtxx= "恭喜玩家".$wjmz."在金山挖宝中受到了幸运女神的垂爱！！获得了大量奖励！！";
include("./msg/msgg02.php");

} else {
}



} else {
}


if($iii==3&&$sss==10||$iii==3&&$sss==20||$iii==3&&$sss==30||$iii==3&&$sss==40||$iii==3&&$sss==50){
//随机
$bz= rand(1, 2);
if($bz ==1){
echo "<font color=red>你受到了幸运女神的垂爱（运气爆棚~~财神驾到）</font>"."<br>";


$bz= rand(1, 10);
//物品加
$wpdz1[]="【金秋的思念】";//名字
$wpdz2[]=6;//物品分类
$wpdz3[]=744;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加

//物品加
$wpdz1[]="〖金豆〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=127;//物品id
$wpdz4[]=50;//	量
$wpdz5[]=1;//	重量
//物品加
//物品加
$wpdz1[]="〖双倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=454;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加
include("./ini/zt_ini.php");
$wjmz=($iniFile->getItem('玩家信息','玩家名字'));
$xtxx= "恭喜玩家".$wjmz."在金山挖宝中受到了幸运女神的垂爱！！获得了大量奖励！！";
include("./msg/msgg02.php");

} else {
}
} else {
}




if($iii==5&&$sss==10||$iii==5&&$sss==20||$iii==5&&$sss==30||$iii==5&&$sss==40||$iii==5&&$sss==50){
//随机
$bz= rand(1, 2);
if($bz ==1){
echo "<font color=red>你受到了幸运女神的垂爱（运气爆棚~~财神驾到）</font>"."<br>";
$bz= rand(1, 10);
//物品加
$wpdz1[]="【金秋的思念】";//名字
$wpdz2[]=6;//物品分类
$wpdz3[]=744;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加

//物品加
$wpdz1[]="〖金豆〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=127;//物品id
$wpdz4[]=66;//	量
$wpdz5[]=1;//	重量
//物品加
//物品加
$wpdz1[]="〖四倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=455;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加

include("./ini/zt_ini.php");
$wjmz=($iniFile->getItem('玩家信息','玩家名字'));
$xtxx= "恭喜玩家".$wjmz."在金山挖宝中受到了幸运女神的垂爱！！获得了大量奖励！！";
include("./msg/msgg02.php");

} else {
}
} else {
}








if($iii==7&&$sss==10||$iii==7&&$sss==20||$iii==7&&$sss==30||$iii==7&&$sss==40||$iii==7&&$sss==50){
//随机
$bz= rand(1, 2);
if($bz ==1){
echo "<font color=red>你受到了幸运女神的垂爱（运气爆棚~~财神驾到）</font>"."<br>";

$bz= rand(1, 10);
//物品加
$wpdz1[]="【金秋的思念】";//名字
$wpdz2[]=6;//物品分类
$wpdz3[]=744;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加
//物品加
$wpdz1[]="〖金豆〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=127;//物品id
$wpdz4[]=88;//	量
$wpdz5[]=1;//	重量
//物品加
	//随机
$sl= rand(1, 10);
//物品加
$wpdz1[]="〖王者宝石包〗（1个）";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=587;//物品id
$wpdz4[]=$sl;//	量
$wpdz5[]=1;//	重量




//物品加
include("./ini/zt_ini.php");
$wjmz=($iniFile->getItem('玩家信息','玩家名字'));
$xtxx= "恭喜玩家".$wjmz."在金山挖宝中受到了幸运女神的垂爱！！";
include("./msg/msgg02.php");

} else {
}
} else {
}





if($iii==10&&$sss==10||$iii==10&&$sss==20||$iii==10&&$sss==30||$iii==10&&$sss==40||$iii==10&&$sss==50){
//随机
$bz= rand(1, 2);
if($bz ==1){
echo "<font color=red>你受到了幸运女神的垂爱（运气爆棚~~财神驾到）</font>"."<br>";

$bz= rand(1, 10);
//物品加
$wpdz1[]="【金秋的思念】";//名字
$wpdz2[]=6;//物品分类
$wpdz3[]=744;//物品id
$wpdz4[]=$bz;//	量
$wpdz5[]=1;//	重量
//物品加
//物品加
$wpdz1[]="〖金豆〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=127;//物品id
$wpdz4[]=128;//	量
$wpdz5[]=1;//	重量
//物品加
//物品加
$wpdz1[]="〖八倍掉宝符〗";//名字
$wpdz2[]=4;//物品分类
$wpdz3[]=456;//物品id
$wpdz4[]=1;//	量
$wpdz5[]=1;//	重量
//物品加

include("./ini/zt_ini.php");
$wjmz=($iniFile->getItem('玩家信息','玩家名字'));
$xtxx= "恭喜玩家".$wjmz."在金山挖宝中受到了幸运女神的垂爱！！获得了大量奖励！！";
include("./msg/msgg02.php");




} else {
}
} else {
}















} else {

}




if($uuu >=1){

include("./rwmap/rwget.php");
} else {

}

?>


