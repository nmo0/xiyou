<?php



echo "<font color=red>【幻想西游GM代码】</font>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=26'><font color=blue>【得到代码】</font></a>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=27'><font color=blue>【判断物品代码】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=1'><font color=blue>【返回GM管理首页】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjid=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";


















?>





