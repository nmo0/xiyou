<?
if($gid==26){
echo '//银两加'.'<br>';
echo '$yl1=999;'.'<br>'; 
echo '$wwpsl=$yl1;'.'<br>'; 
echo 'include("./pz/ini_pz03.php");'.'<br>'; 
echo '//银两加'.'<br>';

} elseif($gid==27){   

echo '//经验加'.'<br>';
echo '$jy=500;'.'<br>'; 
echo 'include("./pz/ini_pzz023.php");'.'<br>'; 
echo '//经验加'.'<br>';


} else {

} 



?>



