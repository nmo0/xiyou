<?
$god=26;
if($gid==$god){	
echo "<font color=black>银两+|</font>";	
} else {
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=26'><font color=blue>银两+|</font></a>";
} 
$god=27;
if($gid==$god){	
echo "<font color=black>经验+|</font>";
} else {
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=27'><font color=blue>经验+|</font></a>";
} 




?>



