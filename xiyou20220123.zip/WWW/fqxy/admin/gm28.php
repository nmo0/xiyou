<?php



echo "<font color=red>【幻想西游GM代码】</font>"."<br>";

echo "<font color=black>//银两加</font>"."<br>";

echo '$yl1=50000;';
echo '$wwpsl=$yl1'; 
echo 'include("./pz/ini_pz03.php")';

echo "<font color=black>//银两加</font>"."<br>";



echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=24'><font color=blue>【返回上页】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjid=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";




?>



