<?php

echo "<font color=red>【系统管理】</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=8'><font color=blue>【发布系统消息】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=2'><font color=blue>【发布官方动态】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=2'><font color=blue>【查看游戏统计】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=22'><font color=blue>【刷新公共数据】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=37'><font color=blue>【刷新排行榜数据】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=39'><font color=blue>【初始化所有奖池】</font></a>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=40'><font color=blue>【全服发奖励】</font></a>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=62'><font color=blue>【全服某个物品数量】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=63'><font color=blue>【全服充值查询】</font></a>"."<br>";


echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=1'><font color=blue>【返回GM管理首页】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjid=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";





?>
