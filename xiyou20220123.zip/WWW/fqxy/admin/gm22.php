<?php



echo "<font color=red>【公共数据管理】</font>"."<br>";

echo "<font color=red>确定要刷新公共数据吗？（刷新后缓存公共数据清空建议在没玩家游戏下进行）</font>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=23'><font color=blue>确认刷新</font></a>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=3'><font color=blue>取消取消</font></a>"."<br>";
echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=1'><font color=blue>【返回GM管理首页】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjid=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";


















?>





