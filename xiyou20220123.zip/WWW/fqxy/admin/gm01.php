<?php

echo "<font color=red>【请选择你需要要操作项目】</font>"."<br>";



echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=2'><font color=blue>【玩家管理】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=3'><font color=blue>【系统管理】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=24'><font color=blue>【幻想西游GM代码】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=43'><font color=blue>【幻想西游充值管理】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=45'><font color=blue>【幻想西游红包管理】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=52'><font color=blue>【幻想西游娱乐统计】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=57'><font color=blue>【提取SDK兑换码】</font></a>"."<br>";


echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjiddd=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";


?>




