<?php



echo "<font color=red>【请选择你要提取的SDK码】</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=58'><font color=blue>【宣传SDK码】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=59'><font color=blue>【拉人SDK码】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=60'><font color=blue>【福利SDK码】</font></a>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=61'><font color=blue>【新区SDK码】</font></a>"."<br>";




echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=1'><font color=blue>【返回GM管理首页】</font></a>"."<br>";

echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjid=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";





?>
