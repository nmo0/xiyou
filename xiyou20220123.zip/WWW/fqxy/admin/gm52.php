<?php
echo "<font color=red>【请选择你需要要操作项目】</font>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=53'><font color=blue>【天降财神统计】</font></a>"."<br>";

echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=54'><font color=blue>【天降红包统计】</font></a>"."<br>";

echo "<br>";
echo "<a href='gm.php?wjid=$wjiddd&&pass=$password&&gid=1'><font color=blue>【返回上级】</font></a>"."<br>";


echo "<br>";
echo "<font color=black>---------------------</font>"."<br>";


echo "<a href=http://".$xxjyurl."/admin/index.php?wjiddd=$wjid&&pass=$password><font color=blue>返回GM管理平台</font></a>"."<br>";


?>
