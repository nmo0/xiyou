<?php

if($cwid ==1){
//名字
$nname="【花斑虎王】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=1000;//系数
//MP
$nmp=500;//系数
//MAXMP
$nmaxmp=500;//系数
//攻击
$ngj=800;//系数
//魔攻
$nmg=200;//系数
//防御
$nfy=600;//系数
//魔防
$nmf=600;
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;



} elseif($cwid ==2){
//名字
$nname="【雪豹大王】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=1100;//系数
//MP
$nmp=600;//系数
//MAXMP
$nmaxmp=600;//系数
//攻击
$ngj=900;//系数
//魔攻
$nmg=200;//系数
//防御
$nfy=600;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	

} elseif($cwid ==3){
//名字
$nname="【狂狼大王】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=1500;//系数
//MP
$nmp=600;//系数
//MAXMP
$nmaxmp=600;//系数
//攻击
$ngj=1100;//系数
//魔攻
$nmg=1100;//系数
//防御
$nfy=900;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
		
	
} elseif($cwid ==4){
//名字
$nname="【双翅飞虎】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=1800;//系数
//MP
$nmp=1000;//系数
//MAXMP
$nmaxmp=1000;//系数
//攻击
$ngj=1500;//系数
//魔攻
$nmg=1500;//系数
//防御
$nfy=1200;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==5){
//名字
$nname="【噬月天狼】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=3000;//系数
//MP
$nmp=600;//系数
//MAXMP
$nmaxmp=600;//系数
//攻击
$ngj=2100;//系数
//魔攻
$nmg=2100;//系数
//防御
$nfy=3000;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==6){
//名字
$nname="【统帅佣】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP

$nmaxhp=3000;//系数
//MP
$nmp=600;//系数
//MAXMP
$nmaxmp=3000;//系数
//攻击
$ngj=2100;//系数
//魔攻
$nmg=2100;//系数
//防御
$nfy=3000;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==7){
//名字
$nname="【通天神鼠】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=3000;//系数
//MP
$nmp=600;//系数
//MAXMP
$nmaxmp=3000;//系数
//攻击
$ngj=2100;//系数
//魔攻
$nmg=2100;//系数
//防御
$nfy=3000;//系数
//冰攻
$nbg=1;
//火攻
$nhg=1;
//雷攻
$nlg=1;
//冰防
$nbf=1;
//火防
$nhf=1;
//雷防
$nlf=1;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
	
} elseif($cwid ==8){
//名字
$nname="【混沌战神】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=40000;//系数
//MP
$nmp=4000;//系数
//MAXMP
$nmaxmp=4000;//系数
//攻击
$ngj=15000;//系数
//魔攻
$nmg=15000;//系数
//防御
$nfy=14000;//系数
//冰攻
$nbg=20;
//火攻
$nhg=20;
//雷攻
$nlg=20;
//冰防
$nbf=20;
//火防
$nhf=20;
//雷防
$nlf=20;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
} elseif($cwid ==9){
//名字
$nname="【九天玄女】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=40000;//系数
//MP
$nmp=4000;//系数
//MAXMP
$nmaxmp=4000;//系数
//攻击
$ngj=15000;//系数
//魔攻
$nmg=15000;//系数
//防御
$nfy=14000;//系数
//冰攻
$nbg=20;
//火攻
$nhg=20;
//雷攻
$nlg=20;
//冰防
$nbf=20;
//火防
$nhf=20;
//雷防
$nlf=20;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==10){
//名字
$nname="【五行裂云兽】";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=40000;//系数
//MP
$nmp=4000;//系数
//MAXMP
$nmaxmp=4000;//系数
//攻击
$ngj=15000;//系数
//魔攻
$nmg=15000;//系数
//防御
$nfy=14000;//系数
//冰攻
$nbg=20;
//火攻
$nhg=20;
//雷攻
$nlg=20;
//冰防
$nbf=20;
//火防
$nhf=20;
//雷防
$nlf=20;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
} elseif($cwid ==11){
	
//名字
$nname="【九尾妖狐】";	
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=100000;//系数
//MP
$nmp=5000;//系数
//MAXMP
$nmaxmp=5000;//系数
//攻击
$ngj=45000;//系数
//魔攻
$nmg=45000;//系数
//防御
$nfy=60000;//系数
//冰攻
$nbg=50;
//火攻
$nhg=50;
//雷攻
$nlg=50;
//冰防
$nbf=50;
//火防
$nhf=50;
//雷防
$nlf=50;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==12){
//名字
$nname="〖瞌睡虫〗（典藏版）";
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=100000;//系数
//MP
$nmp=5000;//系数
//MAXMP
$nmaxmp=5000;//系数
//攻击
$ngj=30000;//系数
//魔攻
$nmg=30000;//系数
//防御
$nfy=30000;//系数
//冰攻
$nbg=20;
//火攻
$nhg=20;
//雷攻
$nlg=20;
//冰防
$nbf=20;
//火防
$nhf=20;
//雷防
$nlf=20;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	
} elseif($cwid ==13){
//名字
$nname="【齐天大圣】";	
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=150000;//系数
//MP
$nmp=5000;//系数
//MAXMP
$nmaxmp=5000;//系数
//攻击
$ngj=60000;//系数
//魔攻
$nmg=60000;//系数
//防御
$nfy=60000;//系数
//冰攻
$nbg=60;
//火攻
$nhg=60;
//雷攻
$nlg=60;
//冰防
$nbf=60;
//火防
$nhf=60;
//雷防
$nlf=60;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	
	} elseif($cwid ==14){
//名字
$nname="【麒麟圣祖】（绝版）";	
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=300000;//系数
//MP
$nmp=10000;//系数
//MAXMP
$nmaxmp=10000;//系数
//攻击
$ngj=100000;//系数
//魔攻
$nmg=100000;//系数
//防御
$nfy=100000;//系数
//冰攻
$nbg=100;
//火攻
$nhg=100;
//雷攻
$nlg=100;
//冰防
$nbf=100;
//火防
$nhf=100;
//雷防
$nlf=100;
//星级
$nxj=0;
//出战状态
$ncz=1;
	
	} elseif($cwid ==15){
//名字
$nname="【凤凰圣祖】（绝版）";	
//等级
$ndj=1;
//HP
$nhp=500;
//MAXHP
$nmaxhp=999999;//系数
//MP
$nmp=10000;//系数
//MAXMP
$nmaxmp=10000;//系数
//攻击
$ngj=300000;//系数
//魔攻
$nmg=300000;//系数
//防御
$nfy=300000;//系数
//冰攻
$nbg=300;
//火攻
$nhg=300;
//雷攻
$nlg=300;
//冰防
$nbf=300;
//火防
$nhf=300;
//雷防
$nlf=300;
//星级
$nxj=0;
//出战状态
$ncz=1;	
	
	


} else{

echo "<font color=black>没有这个宠物id编号".$cwid."请尝试联系gm解决此问题！！</font><br>";

}



?>




